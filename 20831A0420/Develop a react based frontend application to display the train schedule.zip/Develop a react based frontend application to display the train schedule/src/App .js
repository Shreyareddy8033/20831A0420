import './App.css';
import Navbar from './components/Navbar';
import Body_details from './components/Body_details';

function App() {
  return (
    <>
    
    <Navbar></Navbar>
    <Body_details></Body_details>
    </>
  );
}

export default App;
